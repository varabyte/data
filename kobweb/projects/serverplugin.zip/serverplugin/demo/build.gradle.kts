plugins {
    alias(libs.plugins.kotlin.jvm)
}
group = "org.example.serverplugin"
version = "1.0-SNAPSHOT"

tasks.jar {
    // Remove the version number
    archiveFileName.set("${project.name}.jar")
}

dependencies {
    compileOnly(libs.kobweb.server.plugin)
}
