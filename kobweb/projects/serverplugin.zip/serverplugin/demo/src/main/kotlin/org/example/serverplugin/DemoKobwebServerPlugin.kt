package org.example.serverplugin

import com.varabyte.kobweb.server.plugin.KobwebServerPlugin
import io.ktor.server.application.*

class DemoKobwebServerPlugin : KobwebServerPlugin {
    override fun configure(application: Application) {
        application.log.info("REPLACE ME WITH REAL CONFIGURATION")
    }
}
